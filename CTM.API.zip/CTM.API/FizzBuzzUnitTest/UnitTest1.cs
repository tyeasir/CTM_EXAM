using ClassLibraryProject;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace FizzBuzzUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void RangeLow()
        {
            FizzBuzzCompute fb = new FizzBuzzCompute();

            var exception = new Exception("Input must be between 1 and 100");

            Assert.ThrowsException<Exception>(() => fb.Calculate(0));
        }

        [TestMethod]
        public void RangeHigh()
        {
            FizzBuzzCompute fb = new FizzBuzzCompute();

            var exception = new Exception("Input must be between 1 and 100");

            Assert.ThrowsException<Exception>(() => fb.Calculate(105));
        }


        [TestMethod]
        public void TestSample1To15()
        {
            FizzBuzzCompute fb = new FizzBuzzCompute();

            List<string> fbList = fb.Calculate(15);

            string expected = "1,2,Fizz,4,Buzz,Fizz,7,8,Fizz,Buzz,11,Fizz,13,14,FizzBuzz";

            string actual = string.Join(",", fbList);

            Assert.AreEqual(expected, actual);
        }


        [TestMethod]
        public void TestRange1To100()
        {
            FizzBuzzCompute fb = new FizzBuzzCompute();

            List<string> fbList = fb.Calculate(100);

            string expected = "1,2,Fizz,4,Buzz,Fizz,7,8,Fizz,Buzz,11,Fizz,13,14,FizzBuzz,16,17,Fizz,19,Buzz,Fizz,22,23,Fizz,Buzz,26,Fizz,28,29,FizzBuzz,31,32,Fizz,34,Buzz,Fizz,37,38,Fizz,Buzz,41,Fizz,43,44,FizzBuzz,46,47,Fizz,49,Buzz,Fizz,52,53,Fizz,Buzz,56,Fizz,58,59,FizzBuzz,61,62,Fizz,64,Buzz,Fizz,67,68,Fizz,Buzz,71,Fizz,73,74,FizzBuzz,76,77,Fizz,79,Buzz,Fizz,82,83,Fizz,Buzz,86,Fizz,88,89,FizzBuzz,91,92,Fizz,94,Buzz,Fizz,97,98,Fizz,Buzz";

            string actual = string.Join(",", fbList);

            Assert.AreEqual(expected, actual);
        }

    }
}
