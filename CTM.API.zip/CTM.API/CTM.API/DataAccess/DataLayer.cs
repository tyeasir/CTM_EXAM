﻿using ClassLibraryProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CTM.API.DataAccess
{
    public class DataLayer : IDataLayer
    {
        public List<string> FizzBuzz(int n)
        {
            FizzBuzzCompute fb = new FizzBuzzCompute();
           return  fb.Calculate(n);
        }
    }
}
