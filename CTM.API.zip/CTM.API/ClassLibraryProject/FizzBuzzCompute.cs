﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryProject
{
    public class FizzBuzzCompute
    {
        public List<string> Calculate(int n)
        {
            if (n < 1 || n > 100) throw new Exception("Input must be between 1 and 100");
            //if multiple of 3 FIZZ, 5 Buzz, 3 && 5 FIZZBUZZ

            List<string> fizzBuzzList = new List<string>();

            for (int i = 1; i < n + 1; i++)
            {
                string output = "";

                if (i % 3 == 0) { output += "Fizz"; }
                if (i % 5 == 0) { output += "Buzz"; }

                if (output == "") output = i.ToString();

                fizzBuzzList.Add(output);
            }

            return fizzBuzzList;
        }
    }
}
